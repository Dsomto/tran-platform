# Stage 6: Vendor Assurance Engine

This is the shared B1 base archive for your track. Your signed-in stage room
provides the private assignment set and evidence marker; those values do not
change these archive bytes.

## Start

1. Verify this archive against the SHA-256 shown in the stage room.
2. Download the private assignment overlay and place it beside this archive.
3. Read `brief/brief.md`, `brief/integrity-attestation.md`, and
   `common/technical-assessment-contract.md` before running tools.
4. Work only in an environment and scope you own or are explicitly authorized
   to use. Preserve raw evidence and hashes from the first command.
5. Submit one Google Drive folder using the required structure and permissions.

## Runtime responsibility

No external service is required; all vendor claims, telemetry, contract facts, and exact interface fixtures are in this archive.

All workloads run in the candidate's own environment. The programme website
only authenticates access, distributes this archive, and accepts the submission
folder URL. A missing optional tool must be handled through the documented
fallback or adapter behavior, not by scanning a public target.
